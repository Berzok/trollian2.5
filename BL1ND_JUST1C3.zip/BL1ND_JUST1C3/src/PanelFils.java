import java.awt.event.*;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.*;


public class PanelFils extends JPanel implements ActionListener
	{
	JTextField zoneSaisie = new JTextField("        ");
	JButton bouton = new JButton("Clic");
	JTextField zoneMessage = new JTextField(10);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PanelFils()		//
		{
		this.setLayout(new BorderLayout());
		add(zoneSaisie, BorderLayout.SOUTH);
		add(bouton, BorderLayout.WEST);
		bouton.addActionListener(this);
		add(zoneMessage, BorderLayout.EAST);
		}
	public void actionPerformed(ActionEvent parEvt)
		{
		if (parEvt.getSource() == bouton)
			zoneMessage.setText("Bonjour " + zoneSaisie.getText());
		}
	}
