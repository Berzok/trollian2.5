import javax.swing.*;
import java.awt.*;

public class LaFenetre extends JFrame
	{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public LaFenetre (String parTitre)
		{
		super(parTitre);
		PanelFils contentPane = new PanelFils();
		setContentPane(contentPane);
		contentPane.setBackground(new Color(0, 0, 0));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(260, 400); setVisible(true); setLocation(200, 300);
		}
	public static void main(String[] args)
		{
		new LaFenetre("Trollian");
		}
	}
