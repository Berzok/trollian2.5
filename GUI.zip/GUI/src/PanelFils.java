import javax.swing.*;

public class PanelFils extends JPanel
	{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PanelFils()
		{
		JTextField zoneSaisie = new JTextField("Parlez-moi");
		JButton bouton = new JButton("Clic");
		JTextField zoneMessage = new JTextField(10);
		add(zoneSaisie);
		add(bouton);
		add(zoneMessage);
		}
	}
